SCC0270 - Redes Neurais e Aprendizado Profundo  

Alunos:  
- 10716504 - Helbert Moreira Pinto
- 10377708 - João Marcos Della Torre Divino

Exercicio 1 - Implementar e treinar o modelo Adaline para reconhecer os símbolos Y e Y invertido (letra “Y” e letra “Y” invertida)


Para a realização deste exercicio, desenvolvemos os seguintes códigos, que encontram-se na pasta "src": 
- perceptron.py -> implementação do neuronio  
- modelos.py -> código auxiliar para tratar da geração/tratamento/visualização dos dados


Criamos um jupyter notebook contendo um breve resumo da implementação e execução do exercicio.
